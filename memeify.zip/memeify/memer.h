//
// Created by Quintin on 11/22/2022.
//

#ifndef MEMIFY_MEMER_H
#include "SFML\Graphics.hpp"
#include <cmath>
#define MEMIFY_MEMER_H

#endif //MEMIFY_MEMER_H

sf::Image generateMeme(sf::Image base, sf::String topText, sf::String bottomText,
                       int topX, int topY, int bottomX, int bottomY)
{
    sf::Texture texture_meme;
    texture_meme.loadFromImage(base); //makes a texture out of passed image

    int top_height = base.getSize().y;
    //code below makes a sprite out of image
    sf::Sprite meme_sprite;
    meme_sprite.setTexture(texture_meme);
    meme_sprite.setScale(1.f,-1.f);
    meme_sprite.setPosition(0,base.getSize().y);//base.getSize().y
    //meme_sprite.rotate(180);//180

    //std::cout << meme_sprite.getPosition().x << meme_sprite.getPosition().y;

    //code below makes text
    //font practice
    sf::Font font;
    if (!font.loadFromFile("Cave-Story.ttf"))
        throw("Could not find text");
    sf::Text text;
    text.setFont(font);
    text.setCharacterSize(24);
    text.setColor(sf::Color::White);
    text.setString(topText);
    text.setScale(1.f,-1.f);
    auto temp_w = text.getGlobalBounds().width / 2.0f;
    auto temp_h = text.getGlobalBounds().height / 2.0f;
    auto localBounds_W = temp_w + text.getLocalBounds().left;
    auto localBounds_H = temp_h + text.getLocalBounds().top;
    auto rounded_W = round(localBounds_W);
    auto rounded_H = round(localBounds_H);
    text.setOrigin(rounded_W,rounded_H);
    if (topX != -1 and topY == -1)
    {
        text.setPosition(topX, top_height - base.getSize().y/ 2u);
    }
    else if (topX != -1 and topY != -1)
    {
        text.setPosition(topX, top_height - topY);
    }
    else
    {
        text.setPosition(sf::Vector2f{ base.getSize() / 2u });
    }
    //text.setPosition(360,90);

    sf::Font font2;
    if (!font.loadFromFile("Cave-Story.ttf"))
        throw("Could not find text");
    sf::Text text2;
    text2.setFont(font);
    text2.setCharacterSize(18);
    text2.setColor(sf::Color::White);
    text2.setString(bottomText);
    text2.setScale(1.f,-1.f);
    auto temp_w2 = text2.getGlobalBounds().width / 2.0f;
    auto temp_h2 = text2.getGlobalBounds().height / 2.0f;
    auto localBounds_W2 = temp_w2 + text2.getLocalBounds().left;
    auto localBounds_H2 = temp_h2 + text2.getLocalBounds().top;
    auto rounded_W2 = round(localBounds_W2);
    auto rounded_H2 = round(localBounds_H2);
    text2.setOrigin(rounded_W2,rounded_H2);
    if (bottomX != -1 and bottomY == -1)
    {
        text2.setPosition(bottomX, top_height - (base.getSize().y/ 3u)*2);
    }
    else if (bottomX != -1 and bottomY != -1)
    {
        text2.setPosition(bottomX, top_height - bottomY);
    }
    else
    {
        text2.setPosition(base.getSize().x/2u,(base.getSize().y/ 3u)*1);
    }


    sf::RenderTexture texture;
    if (!texture.create(base.getSize().x, base.getSize().y))
        throw("could not create texture");

    texture.draw(meme_sprite);
    texture.draw(text);
    texture.draw(text2);
    sf::Image returner = (texture.getTexture().copyToImage());
    return returner;
}